# JANI AI — Mobile-friendly project

## Included
- `server.js`: backend for real AI responses. API key stays server-side.
- `public/index.html`: mobile-friendly chat page.
- `package.json`: Node.js dependency and start script.

## Set up on Replit using your phone
1. Sign in at https://replit.com and create/open a Node.js project.
2. Upload/extract these files so `server.js`, `package.json`, and `public/` are in the project root.
3. Open Replit **Secrets / Environment variables** and add `OPENAI_API_KEY` with your own API key.
4. Optional: add `OPENAI_MODEL` set to a model your API account can access. Default is `gpt-5`.
5. Run `npm install`, then `npm start` (or use Replit's Run button after setting its run command).
6. Open the web preview. The status at the top says whether the API key is configured.

## Important
- Never paste the API key into the chat or put it in `public/index.html`.
- ChatGPT subscription and API billing are separate; API use may cost money.
- If your API account cannot access the default model, set `OPENAI_MODEL` to one you can access.
- If JANI shows “Setup needed”, add the secret and restart.

### Chat appearance
The interface uses a WhatsApp-inspired emerald/teal palette, a subtle mint patterned chat wallpaper, and light green user-message bubbles. The design uses CSS patterns rather than a pink background or a copied WhatsApp wallpaper image.
