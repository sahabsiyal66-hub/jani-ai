const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-5";

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname, "public")));

const instructions = `You are JANI AI: funny, clever, confident, fearless, Zorro-like friend.
Use natural Roman Urdu by default when the user writes Roman Urdu; also understand Urdu and English.
Be witty, warm, conversational and original. Respond to what the user actually says.
Never replace an answer with generic repetition like "Aap keh rahe hain Jani".
Friendly roasting is welcome, but do not use hateful slurs, threats, or target protected traits.
If the user is upset or serious, be caring and reduce jokes. Do not claim memories not in supplied history.`;

app.get("/api/health", (_req,res) => res.json({ok:true, aiConfigured:!!API_KEY, model:MODEL}));

app.post("/api/chat", async (req,res) => {
  try {
    if (!API_KEY) return res.status(503).json({error:"JANI ka AI connection set nahi hua. Replit Secrets mein OPENAI_API_KEY add karo."});
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const safe = messages.filter(m => m && ["user","assistant"].includes(m.role) && typeof m.content==="string")
      .slice(-20).map(m=>({role:m.role,content:[{type:"input_text",text:m.content.slice(0,5000)}]}));
    if (!safe.length || messages[messages.length-1]?.role!=="user") return res.status(400).json({error:"Pehle apna message likho."});
    const r = await fetch("https://api.openai.com/v1/responses", {
      method:"POST",
      headers:{"Authorization":"Bearer "+API_KEY,"Content-Type":"application/json"},
      body:JSON.stringify({model:MODEL,instructions,input:safe})
    });
    const data = await r.json();
    if (!r.ok) {
      console.error("OpenAI API error:",r.status,data?.error?.message || "unknown");
      return res.status(502).json({error:"AI connection error. API key, model aur API access check karo."});
    }
    let reply = data.output_text;
    if (!reply && Array.isArray(data.output)) reply=data.output.flatMap(x=>x.content||[]).filter(x=>x.type==="output_text").map(x=>x.text).join("\n");
    res.json({reply:reply || "Yaar, is dafa jawab nahi bana. Dobara try karo!"});
  } catch(e) {
    console.error("Chat error:",e.message);
    res.status(500).json({error:"Connection mein masla hai. Server dobara check karo."});
  }
});
app.listen(PORT,"0.0.0.0",()=>console.log("JANI AI running on port "+PORT));
